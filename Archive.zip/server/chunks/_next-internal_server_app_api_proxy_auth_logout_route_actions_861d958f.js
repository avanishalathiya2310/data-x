module.exports=[30349,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_proxy_auth_logout_route_actions_861d958f.js.map