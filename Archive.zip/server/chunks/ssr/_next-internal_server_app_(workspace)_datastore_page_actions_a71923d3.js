module.exports=[59172,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28workspace%29_datastore_page_actions_a71923d3.js.map