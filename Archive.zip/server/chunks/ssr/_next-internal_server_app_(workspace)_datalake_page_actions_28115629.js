module.exports=[42695,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28workspace%29_datalake_page_actions_28115629.js.map