module.exports=[40523,a=>{"use strict";var b=a.i(87924);a.i(72131);var c=a.i(14174);a.s(["default",0,()=>{let{currentToken:a}=(0,c.useSelector)(a=>a.users);return(0,b.jsx)("div",{className:"h-[calc(100vh-52px)]",children:(0,b.jsx)("iframe",{title:"Codepages",src:`https://codepage-dev.datax.nuvinno.no/lab?accessToken=${encodeURIComponent(a)}
          `,className:"w-full h-full",allowFullScreen:!0},`${a}`)})}])}];

//# sourceMappingURL=src_app_%28workspace%29_codepages_page_643fb362.js.map