module.exports=[35325,a=>{"use strict";var b=a.i(87924);a.i(72131);var c=a.i(14174);a.s(["default",0,()=>{let{currentToken:a}=(0,c.useSelector)(a=>a.users);return(0,b.jsx)("div",{className:"h-[calc(100vh-52px)]"})}])}];

//# sourceMappingURL=src_app_%28workspace%29_datalake_page_2228ab2b.js.map