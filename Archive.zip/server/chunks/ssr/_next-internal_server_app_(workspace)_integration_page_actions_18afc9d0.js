module.exports=[80293,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28workspace%29_integration_page_actions_18afc9d0.js.map