module.exports=[63546,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28workspace%29_codepages_page_actions_e2366d4d.js.map