module.exports=[96561,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28workspace%29_admin_teams_page_actions_e79cfda3.js.map