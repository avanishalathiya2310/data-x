module.exports=[19866,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28workspace%29_collections_page_actions_9da8dfc7.js.map