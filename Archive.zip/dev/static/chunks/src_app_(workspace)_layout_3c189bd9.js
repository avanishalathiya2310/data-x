(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_3ccbabc0._.js",
  "static/chunks/src_010ae731._.js",
  "static/chunks/node_modules_react-toastify_dist_ReactToastify_487faac8.css"
],
    source: "dynamic"
});
