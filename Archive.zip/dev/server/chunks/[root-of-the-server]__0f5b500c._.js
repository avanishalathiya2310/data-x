module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/app/api/proxy/auth/me/route.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
;
async function GET(req) {
    try {
        // const cookie = req.headers.get("cookie") || "";
        // const upstream = await fetch("https://app.datax.nuvinno.no/.auth/me", {
        //   method: "GET",
        //   headers: {
        //     // Forward incoming cookies so auth works server-side
        //     cookie,
        //     // Ensure JSON back
        //     accept: "application/json",
        //   },
        //   // Do not cache auth
        //   cache: "no-store",
        // });
        // const body = await upstream.text();
        // // Pass through status and content-type
        // const res = new NextResponse(body, {
        //   status: upstream.status,
        //   headers: {
        //     "content-type": upstream.headers.get("content-type") || "application/json",
        //   },
        // });
        // // Forward Set-Cookie from upstream if present
        // const setCookie = upstream.headers.get("set-cookie");
        // if (setCookie) {
        //   res.headers.set("set-cookie", setCookie);
        // }
        const res = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(// SuperAdmin
        [
            {
                access_token: "eyJ0eXAiOiJKV1QiLCJub25jZSI6IlpOVkc0dTFUOTN4U3lUWld5N3hyUDY5OTVvUzE1MVh3Z2tPZHljZ09ncTgiLCJhbGciOiJSUzI1NiIsIng1dCI6InJ0c0ZULWItN0x1WTdEVlllU05LY0lKN1ZuYyIsImtpZCI6InJ0c0ZULWItN0x1WTdEVlllU05LY0lKN1ZuYyJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC80ODc0ZGNmMS1kYjFjLTQ3NDAtYTY2ZC0zZTA5NThjZTE3MGEvIiwiaWF0IjoxNzY1ODY2OTc1LCJuYmYiOjE3NjU4NjY5NzUsImV4cCI6MTc2NTg3MjA1MCwiYWNjdCI6MSwiYWNyIjoiMSIsImFjcnMiOlsicDEiXSwiYWlvIjoiQWJRQVMvOGFBQUFBajJNb1VpWVY5M0tSWnNrS1ZMVE0wNnM5ZWUzSmRDKzk3cklCRWxSblk2NTV6VlZxSFB3ZVlpbE9IU2lIOUtHaDVxWXFGMHdWOThTUlNHWThzSWMxdHZReTUxYUFUK2ZBQ3M0ejRjRnhXbGU5d01LeGl5Vi9RYUt0czNPTC9jQlZxbENkMXR4eVJITjFpeHRIbForR2Z5WU14WmZZLzJOY1dMMG9Xa04vRktDTHF3R2cyOVZFclBDYUdvd25EcEY3ekxpSkxOc0o0ZExBdkY2dnVyNEgzTnVRRktSNXZPaUNmQVk5aVV3clYzQT0iLCJhbHRzZWNpZCI6IjU6OjEwMDMyMDA0QjFFODgyRTgiLCJhbXIiOlsicHdkIiwibWZhIl0sImFwcF9kaXNwbGF5bmFtZSI6Im9hdXRoMi1wcm94eSIsImFwcGlkIjoiMTUxNTlhZjgtMmI0NC00NjIzLTlkYTYtN2E3ZGU4ODRhZjcyIiwiYXBwaWRhY3IiOiIxIiwiZW1haWwiOiJraXNoYW5AYXJpc29mdC10ZWNobm9sb2dpZXMuY29tIiwiaWRwIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvNWE4MDQ0OWQtYWI1Ni00N2M4LWEyZTgtMTg2NjdlYzM4ZmE5LyIsImlkdHlwIjoidXNlciIsImlwYWRkciI6IjI0MDU6MjAxOjIwMGM6YzIwYzo2OTAyOmVjMzA6MmMwNjo2NTdjIiwibmFtZSI6Iktpc2hhbiBNb3ZhbGl5YSIsIm9pZCI6IjE5MjZjNzlmLTAzZjItNDI5Yi1iODFiLTc0NjM4YTU4MjkwZSIsInBsYXRmIjoiOCIsInB1aWQiOiIxMDAzMjAwNTEwMTgxMjdDIiwicmgiOiIxLkFhOEE4ZHgwU0J6YlFFZW1iVDRKV000WENnTUFBQUFBQUFBQXdBQUFBQUFBQUFCS0FUV3ZBQS4iLCJzY3AiOiJlbWFpbCBvcGVuaWQgcHJvZmlsZSIsInNpZCI6IjAwYjk5M2U5LWQ3OGEtYTU0Zi03MjIyLWRhMzJlMjJjMDQwMiIsInN1YiI6Imd2cEdsaXEzdWR2cFVCdGl2WE54ZkZJbVJDemJRaV9VeHExUElnQlBvSHciLCJ0ZW5hbnRfcmVnaW9uX3Njb3BlIjoiRVUiLCJ0aWQiOiI0ODc0ZGNmMS1kYjFjLTQ3NDAtYTY2ZC0zZTA5NThjZTE3MGEiLCJ1bmlxdWVfbmFtZSI6Imtpc2hhbkBhcmlzb2Z0LXRlY2hub2xvZ2llcy5jb20iLCJ1dGkiOiJ1VzlkcHFQSWtVeU1USnp2ekEwU0FBIiwidmVyIjoiMS4wIiwid2lkcyI6WyIxM2JkMWM3Mi02ZjRhLTRkY2YtOTg1Zi0xOGQzYjgwZjIwOGEiXSwieG1zX2FjZCI6MTc2MDcwNjg2MiwieG1zX2FjdF9mY3QiOiI5IDMiLCJ4bXNfZnRkIjoiM0dGcm1rX2RueDdpX2VhTEd3Rk9oZG9Fbm9yakpGQjhYM1lWb0otYXl0MEJabkpoYm1ObFl5MWtjMjF6IiwieG1zX2lkcmVsIjoiNSAyNiIsInhtc19zdCI6eyJzdWIiOiJ1LWppYmdXemRCT2FjSmRmd0F3R01GWGRNNzlCbC0telBxMWlXajdENFFFIn0sInhtc19zdWJfZmN0IjoiNiAzIiwieG1zX3RjZHQiOjE3MDcwNjc4NzUsInhtc190ZGJyIjoiRVUiLCJ4bXNfdG50X2ZjdCI6IjMgNiJ9.cZVFFT4XMkh6avxQt3wbuzO051OCo1vc0aa9t0gL5ixDFt8wtkA7F2EPkNIAXDky6LWh3WdfHYKdKU2zicXJAgtflMT5wfhdKwL2ENWDr3OwI5URw2OEBbgJ0cC7NJHF-zyvdU_xYBzd7t_WIhLEktHon119NQHHl4Sq7tDnHuwz31L13XUjm2TodOXQY6cwOTss6Ar0NpJazDlhi1h76UOMGnrTsZ4S6EQZ4IObyFzViXfTBdeuCx1O6P4w_hPFFkt0GNFuzDNIpUhH5fDs4ONSwvpaZ2n4nw_6sSzlY3iJoD6RpVOAwuY5pCcw7eO2RbqehEkkezoR9VYovDq8Bg",
                expires_on: "2025-12-16T08:00:50.4151544Z",
                id_token: "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6InJ0c0ZULWItN0x1WTdEVlllU05LY0lKN1ZuYyJ9.eyJhdWQiOiIxNTE1OWFmOC0yYjQ0LTQ2MjMtOWRhNi03YTdkZTg4NGFmNzIiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vNDg3NGRjZjEtZGIxYy00NzQwLWE2NmQtM2UwOTU4Y2UxNzBhL3YyLjAiLCJpYXQiOjE3NjU4NjY5NzUsIm5iZiI6MTc2NTg2Njk3NSwiZXhwIjoxNzY1ODcwODc1LCJhaW8iOiJBY1FBTy84YUFBQUFDZmhEOU1HbGx2ZEZTUUZiQk5xZE9jM29BWTZKT3RuNzJUTVJSTlh5L29oZnl6V3RxdWt3bXVrMWg2amNyTTZ6SWExYlRDZnZEZnZNb0VxcWQvMk12MkJHYTRzeEdhWkJHbXRJRGtiYjFSWDlWa1ppdmhTc0VJZWROK1BoVXVmN0p6cWVUcXNwWENjSWx4OW5nQ3kzODU0YzJ6UU5obVdQTnowNDhzQ0pQelF4aVlGN2RsZ1NHR1lRN2UwTm1EVnpDMlZHVXlGTHBWMUhzeXBtdmdIUFlMcGFKdlNOZXJpRWpwWkdjS1FidTJTZmJvZFR3Z0xabTVMSXFzbW9kRWdZIiwiZW1haWwiOiJraXNoYW5AYXJpc29mdC10ZWNobm9sb2dpZXMuY29tIiwiaWRwIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvNWE4MDQ0OWQtYWI1Ni00N2M4LWEyZTgtMTg2NjdlYzM4ZmE5LyIsIm5hbWUiOiJLaXNoYW4gTW92YWxpeWEiLCJub25jZSI6IjMzYjAwYmQ1N2U1MzRkMDdhM2E5YjgzMzUyMWVlYjU5XzIwMjUxMjE2MDY0NjEwIiwib2lkIjoiMTkyNmM3OWYtMDNmMi00MjliLWI4MWItNzQ2MzhhNTgyOTBlIiwicHJlZmVycmVkX3VzZXJuYW1lIjoia2lzaGFuQGFyaXNvZnQtdGVjaG5vbG9naWVzLmNvbSIsInJoIjoiMS5BYThBOGR4MFNCemJRRWVtYlQ0SldNNFhDdmlhRlJWRUt5TkduYVo2ZmVpRXIzSktBVFd2QUEuIiwic2lkIjoiMDBiOTkzZTktZDc4YS1hNTRmLTcyMjItZGEzMmUyMmMwNDAyIiwic3ViIjoidS1qaWJnV3pkQk9hY0pkZndBd0dNRlhkTTc5QmwtLXpQcTFpV2o3RDRRRSIsInRpZCI6IjQ4NzRkY2YxLWRiMWMtNDc0MC1hNjZkLTNlMDk1OGNlMTcwYSIsInV0aSI6InVXOWRwcVBJa1V5TVRKenZ6QTBTQUEiLCJ2ZXIiOiIyLjAifQ.kZi0SVBnzjujRMETA1IcxH6L7LTsOL_ssBtmLiagr7z-WIhOE_EKQnOBrbPn9u_kjd47jPs_2nAAX8OG1e9CyHygRFirqxHBqAuXb2ya7LU0p4F5y0bUv0guRODhf3eytbwd5pEACaHLn88X-zes8YzHGoj4XwDPje04HwM0xPOGaYnoVHYWglnyxl0y4DcQXOtXCrkFKfq3UEx_MnJDoH7Crp9CZIBfhMMNGUKKtWikcPrJBgk_4ZhG5KvaXFaOH6DcVBeyK6qEggt1uljUZqtUsX7zsRS3-hDKXiyQ_whKgz6mO7A6M5M5BwWIE6NffnAp0L_qL2fO1m9XV37Dzg",
                provider_name: "aad",
                user_claims: [
                    {
                        typ: "aud",
                        val: "15159af8-2b44-4623-9da6-7a7de884af72"
                    },
                    {
                        typ: "iss",
                        val: "https://login.microsoftonline.com/4874dcf1-db1c-4740-a66d-3e0958ce170a/v2.0"
                    },
                    {
                        typ: "iat",
                        val: "1765866973"
                    },
                    {
                        typ: "nbf",
                        val: "1765866973"
                    },
                    {
                        typ: "exp",
                        val: "1765870873"
                    },
                    {
                        typ: "aio",
                        val: "AZQAa/8aAAAA+g+7c5Zg0Gufyboo1MlT8bxZF35JrRb+ChO6bzHQDQtrssMFhFWq0hVJh/Z/KraYEl5gehc5NaMuaay1FRnsYxXRJttkuDhud+oFQZ0Y797Sg/LTE7ekHm2cV+DYXJDTW8PVOH7khufxEs2A9HD0XKPqPie6joa0qSVzKjxGDpnfRGe7hZfq74TQ5VnNpd7T"
                    },
                    {
                        typ: "c_hash",
                        val: "o5ndLnaB-l8SRQmUBGQj9w"
                    },
                    {
                        typ: "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress",
                        val: "kishan@arisoft-technologies.com"
                    },
                    {
                        typ: "http://schemas.microsoft.com/identity/claims/identityprovider",
                        val: "https://sts.windows.net/5a80449d-ab56-47c8-a2e8-18667ec38fa9/"
                    },
                    {
                        typ: "name",
                        val: "Kishan Movaliya"
                    },
                    {
                        typ: "nonce",
                        val: "33b00bd57e534d07a3a9b833521eeb59_20251216064610"
                    },
                    {
                        typ: "http://schemas.microsoft.com/identity/claims/objectidentifier",
                        val: "1926c79f-03f2-429b-b81b-74638a58290e"
                    },
                    {
                        typ: "preferred_username",
                        val: "kishan@arisoft-technologies.com"
                    },
                    {
                        typ: "rh",
                        val: "1.Aa8A8dx0SBzbQEembT4JWM4XCviaFRVEKyNGnaZ6feiEr3JKATWvAA."
                    },
                    {
                        typ: "sid",
                        val: "00b993e9-d78a-a54f-7222-da32e22c0402"
                    },
                    {
                        typ: "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier",
                        val: "u-jibgWzdBOacJdfwAwGMFXdM79Bl--zPq1iWj7D4QE"
                    },
                    {
                        typ: "http://schemas.microsoft.com/identity/claims/tenantid",
                        val: "4874dcf1-db1c-4740-a66d-3e0958ce170a"
                    },
                    {
                        typ: "uti",
                        val: "p5zrcFPlf0ySgIgDoGoDAA"
                    },
                    {
                        typ: "ver",
                        val: "2.0"
                    }
                ],
                user_id: "kishan@arisoft-technologies.com"
            }
        ], // Admin
        // [
        //   {
        //     access_token:
        //       "eyJ0eXAiOiJKV1QiLCJub25jZSI6InJrTHlTZjhXaTdwWlpSX0FpZnE4SXFqeDUzRHZiNTlHZkpMb0NEczAtc0kiLCJhbGciOiJSUzI1NiIsIng1dCI6InJ0c0ZULWItN0x1WTdEVlllU05LY0lKN1ZuYyIsImtpZCI6InJ0c0ZULWItN0x1WTdEVlllU05LY0lKN1ZuYyJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC80ODc0ZGNmMS1kYjFjLTQ3NDAtYTY2ZC0zZTA5NThjZTE3MGEvIiwiaWF0IjoxNzY1OTYxOTUwLCJuYmYiOjE3NjU5NjE5NTAsImV4cCI6MTc2NTk2NTg1NSwiYWNjdCI6MCwiYWNyIjoiMSIsImFjcnMiOlsicDEiXSwiYWlvIjoiQVpRQWEvOGFBQUFBTm03bUJYcUtOSmE3VmtwR1pjM0h6Ly9SL1MvNGhKOFZ2MWwxOGh3R0ZpcStyTkQvcENyeE02c1FCRnJ0NDBuaE9qUkRtbnVwMnRMVTFyWTRITmV2aFVZQk9tTThqc2pWOW5WdlBwV0N2dzZnMHE2YWNaOTdKQkJyV1psQSsyRWdteDAzRFl6ZjUxeEtQb2R4TW43OGc3N1kzNE9qQytqellCSkNJd25hYm84RU9RQk1rcVk3RTByMzVRaWltL0hmIiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJhcHBfZGlzcGxheW5hbWUiOiJvYXV0aDItcHJveHkiLCJhcHBpZCI6IjE1MTU5YWY4LTJiNDQtNDYyMy05ZGE2LTdhN2RlODg0YWY3MiIsImFwcGlkYWNyIjoiMSIsImZhbWlseV9uYW1lIjoiTW92YWxpeWEiLCJnaXZlbl9uYW1lIjoiS2lzaGFuIiwiaWR0eXAiOiJ1c2VyIiwiaXBhZGRyIjoiMjQwNToyMDE6MjAwYzpjMjBjOjRiMmQ6NmNmNDozYTBmOjc1MTIiLCJuYW1lIjoiS2lzaGFuIE1vdmFsaXlhIiwib2lkIjoiNWM1MjdkOTktMjY2Ni00NDkzLTg5NGYtMTdlOTI3NjQ4NDk5IiwicGxhdGYiOiI4IiwicHVpZCI6IjEwMDMyMDA1MkJGOTgwQjEiLCJyaCI6IjEuQWE4QThkeDBTQnpiUUVlbWJUNEpXTTRYQ2dNQUFBQUFBQUFBd0FBQUFBQUFBQUJLQWZhdkFBLiIsInNjcCI6ImVtYWlsIG9wZW5pZCBwcm9maWxlIiwic2lkIjoiMDBiOGY3YTktY2ExMS00YmIyLTU3YjEtZTFkMWEzOTI0NDYyIiwic2lnbmluX3N0YXRlIjpbImttc2kiXSwic3ViIjoianVLWWhmZzRlQjhNaDhFMlBWVlEzcG9ZbnNZYVE2dmhhNERTZGNDN1V3dyIsInRlbmFudF9yZWdpb25fc2NvcGUiOiJFVSIsInRpZCI6IjQ4NzRkY2YxLWRiMWMtNDc0MC1hNjZkLTNlMDk1OGNlMTcwYSIsInVuaXF1ZV9uYW1lIjoiS2lzaGFuLk1vdmFsaXlhQG51dmlubm8uY29tIiwidXBuIjoiS2lzaGFuLk1vdmFsaXlhQG51dmlubm8uY29tIiwidXRpIjoiNGVJX194TTdIa0M1WWJDNUJzc2tBQSIsInZlciI6IjEuMCIsIndpZHMiOlsiYjc5ZmJmNGQtM2VmOS00Njg5LTgxNDMtNzZiMTk0ZTg1NTA5Il0sInhtc19hY2QiOjE3NjA3MDY4NjIsInhtc19hY3RfZmN0IjoiOSAzIiwieG1zX2Z0ZCI6IkdkNlpDU0RlUFBaV0hsazVFOVBadjlGSWw2em1HeGFlSWNJdDdVbHhkMEFCYzNkbFpHVnVZeTFrYzIxeiIsInhtc19pZHJlbCI6IjE4IDEiLCJ4bXNfc3QiOnsic3ViIjoiT19DMnIzaDR2eVhBSEdYUC1fUnBwdzFsWW56aGRucGJQUF9IcUFqTWZEMCJ9LCJ4bXNfc3ViX2ZjdCI6IjQgMyIsInhtc190Y2R0IjoxNzA3MDY3ODc1LCJ4bXNfdGRiciI6IkVVIiwieG1zX3RudF9mY3QiOiIzIDIifQ.OJEQOW7d-r6HH4kHuGdZLPKinlSAFuuDLvmT3aQYaKqk7kPixSzp71dna9pqJ4s5Ik_NkQ1ApsrNJeSGFz3ul9t0AR3NkeUZJeHnnVhLJuvFFwmPUaIaq_q97lK_wXDdGT6Fo7R__WzfGqgH-Q_uJRTflXTsn12wNRqRRCEJCO52nKkTSJJX4rDgz01lQG2-Lu5BMKfjPpCQIuak-ARaZExSMhu09DGNzvYhNg6I4DgHwdawpH-I1gBUQbA6kKSJNN-LO2sucfcIdGYZC1DU3JHTJKhKkFiXMOPs5dbKoR_75QtdsNqQ2uwPfLscQtVXPHSw6RNfOo6yyyM9DiKqCQ",
        //     expires_on: "2025-12-17T10:04:14.9054725Z",
        //     id_token:
        //       "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6InJ0c0ZULWItN0x1WTdEVlllU05LY0lKN1ZuYyJ9.eyJhdWQiOiIxNTE1OWFmOC0yYjQ0LTQ2MjMtOWRhNi03YTdkZTg4NGFmNzIiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vNDg3NGRjZjEtZGIxYy00NzQwLWE2NmQtM2UwOTU4Y2UxNzBhL3YyLjAiLCJpYXQiOjE3NjU5NjE5NTAsIm5iZiI6MTc2NTk2MTk1MCwiZXhwIjoxNzY1OTY1ODUwLCJhaW8iOiJBYlFBUy84YUFBQUE0cFhFZkFlQTZxc0RZVjVRWGlSbnJvaW9rS1VTalBvYjMxdEtaVll1eWkwaVh6djZiUi9idG5ReDJuaGV6TDNYdXNoUnVBN05hQ1BscjgyanEra2pCUzRPUWk5UFFvSG1iNGFQOEE0VGRxNElhdjkzdm5LTGIvakFmMWd0TVAyTkQ2ZG9TcEFUMkY2TmJqN3RicUdoQXhyVm9jRGpmVGZtRVVrWTI2L1p4eno0Rko3ZnJhcTlERm9zRWJiakpJcVVaUUlLUGxXZVVldHg2S0o2NUlFOTJkeVpMa00vRVNSTzVEUGxMQWlIY2NzPSIsImVtYWlsIjoiS2lzaGFuLk1vdmFsaXlhQG51dmlubm8uY29tIiwiZ3JvdXBzIjpbIjNmNDc3ZjlkLTU3ZGUtNDY3OS04YjRkLWI1ZTlkZTI0YmUwMiIsIjdjZjlkNTE1LWVkYWYtNGQzOC1iODNjLTU4MzYyODAyMzIxMSIsIjQ5YjgyYTMwLTdjY2MtNDcwZS1iMmFkLTc2ZmJjMDMzYmI2OCIsIjViMjVlYzdkLTk5NzMtNDA0ZC05YzZkLWYxZjczMjJjMWY0MCJdLCJuYW1lIjoiS2lzaGFuIE1vdmFsaXlhIiwibm9uY2UiOiJiZTJiMjY4OGUxMGE0ZDJmOTMxYTQwMjk1NzcwZDViOF8yMDI1MTIxNzA5MDkwNiIsIm9pZCI6IjVjNTI3ZDk5LTI2NjYtNDQ5My04OTRmLTE3ZTkyNzY0ODQ5OSIsInByZWZlcnJlZF91c2VybmFtZSI6Iktpc2hhbi5Nb3ZhbGl5YUBudXZpbm5vLmNvbSIsInJoIjoiMS5BYThBOGR4MFNCemJRRWVtYlQ0SldNNFhDdmlhRlJWRUt5TkduYVo2ZmVpRXIzSktBZmF2QUEuIiwic2lkIjoiMDBiOGY3YTktY2ExMS00YmIyLTU3YjEtZTFkMWEzOTI0NDYyIiwic3ViIjoiT19DMnIzaDR2eVhBSEdYUC1fUnBwdzFsWW56aGRucGJQUF9IcUFqTWZEMCIsInRpZCI6IjQ4NzRkY2YxLWRiMWMtNDc0MC1hNjZkLTNlMDk1OGNlMTcwYSIsInV0aSI6IjRlSV9feE03SGtDNVliQzVCc3NrQUEiLCJ2ZXIiOiIyLjAifQ.MZkJoo8q0EtX4QkyPKQI4dQi9TtFYoOjrgWfiV9-HYmkBlE_uctPBG4Pd2ZtGLdALNct2JncSRClxiBuskxQKCj8AcCarqanViutDIwQXRPIFJTVywybZdLiDuZMKlWWQrGN7mRNckpY1p-23PURzNmZu_DZ_Ozdr63Eyf_GULOQxUHfnGsw9-smadfpFjYBWUR7tpfBMJGqqVxAQJjgelqSbOtQABpq3tgyiDUmoHwbnZVUbS6DdmJl23r5ElUgZbv2t91ERgiKhj_YFEeY4a8xhBdqw4M3oiG6FFo_dxz6r3chGGiOroL6mrT2KrAH6s1qbmNFeSDfedu64SFlAQ",
        //     provider_name: "aad",
        //     user_claims: [
        //       {
        //         typ: "aud",
        //         val: "15159af8-2b44-4623-9da6-7a7de884af72",
        //       },
        //       {
        //         typ: "iss",
        //         val: "https://login.microsoftonline.com/4874dcf1-db1c-4740-a66d-3e0958ce170a/v2.0",
        //       },
        //       {
        //         typ: "iat",
        //         val: "1765961950",
        //       },
        //       {
        //         typ: "nbf",
        //         val: "1765961950",
        //       },
        //       {
        //         typ: "exp",
        //         val: "1765965850",
        //       },
        //       {
        //         typ: "aio",
        //         val: "AYQAe/8aAAAAlwNUcHz7DPEzQ4hhWro3WvaMjEwktf60ztBdTpDmWY7TxJDhI657ogWmy+V0XYtOxRWJTxmAIF0CANtJugLwEuSExN+P3NPUjQZWkUAPayiFobKvwVVxyEW7WmxPGhtjqLYpVou+ZV+HAYcmz+Y8k+NhmTBZP9ccgis4e9Tf45A=",
        //       },
        //       {
        //         typ: "c_hash",
        //         val: "aQ8evqRNxUufM7VR8WyPbA",
        //       },
        //       {
        //         typ: "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress",
        //         val: "Kishan.Movaliya@nuvinno.com",
        //       },
        //       {
        //         typ: "groups",
        //         val: "3f477f9d-57de-4679-8b4d-b5e9de24be02",
        //       },
        //       {
        //         typ: "groups",
        //         val: "7cf9d515-edaf-4d38-b83c-583628023211",
        //       },
        //       {
        //         typ: "groups",
        //         val: "49b82a30-7ccc-470e-b2ad-76fbc033bb68",
        //       },
        //       {
        //         typ: "groups",
        //         val: "5b25ec7d-9973-404d-9c6d-f1f7322c1f40",
        //       },
        //       {
        //         typ: "name",
        //         val: "Kishan Movaliya",
        //       },
        //       {
        //         typ: "nonce",
        //         val: "be2b2688e10a4d2f931a40295770d5b8_20251217090906",
        //       },
        //       {
        //         typ: "http://schemas.microsoft.com/identity/claims/objectidentifier",
        //         val: "5c527d99-2666-4493-894f-17e927648499",
        //       },
        //       {
        //         typ: "preferred_username",
        //         val: "Kishan.Movaliya@nuvinno.com",
        //       },
        //       {
        //         typ: "rh",
        //         val: "1.Aa8A8dx0SBzbQEembT4JWM4XCviaFRVEKyNGnaZ6feiEr3JKAfavAA.",
        //       },
        //       {
        //         typ: "sid",
        //         val: "00b8f7a9-ca11-4bb2-57b1-e1d1a3924462",
        //       },
        //       {
        //         typ: "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier",
        //         val: "O_C2r3h4vyXAHGXP-_Rppw1lYnzhdnpbPP_HqAjMfD0",
        //       },
        //       {
        //         typ: "http://schemas.microsoft.com/identity/claims/tenantid",
        //         val: "4874dcf1-db1c-4740-a66d-3e0958ce170a",
        //       },
        //       {
        //         typ: "uti",
        //         val: "U-uwxhEZk025UHoQQe8hAA",
        //       },
        //       {
        //         typ: "ver",
        //         val: "2.0",
        //       },
        //     ],
        //     user_id: "Kishan.Movaliya@nuvinno.com",
        //   },
        // ],
        {
            status: 200
        });
        return res;
    } catch (err) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            message: "Proxy error",
            error: err && err.message || String(err)
        }, {
            status: 502
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0f5b500c._.js.map