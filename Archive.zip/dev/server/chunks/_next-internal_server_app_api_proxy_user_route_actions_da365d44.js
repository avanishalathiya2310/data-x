module.exports = [
"[project]/.next-internal/server/app/api/proxy/user/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_proxy_user_route_actions_da365d44.js.map