module.exports = [
"[project]/.next-internal/server/app/(workspace)/integration/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28workspace%29_integration_page_actions_18afc9d0.js.map