module.exports = [
"[project]/.next-internal/server/app/(workspace)/datastore/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28workspace%29_datastore_page_actions_a71923d3.js.map