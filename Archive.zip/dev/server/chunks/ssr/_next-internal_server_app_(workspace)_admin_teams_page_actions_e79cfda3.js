module.exports = [
"[project]/.next-internal/server/app/(workspace)/admin/teams/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28workspace%29_admin_teams_page_actions_e79cfda3.js.map